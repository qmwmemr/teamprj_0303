package kiosk.membership;

public interface Member {

}
