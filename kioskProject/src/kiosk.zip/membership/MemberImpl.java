package kiosk.membership;

public class MemberImpl {

}
