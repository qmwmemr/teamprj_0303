package kiosk.payment.saving;

import java.util.ArrayList;


public class MyDB {
	
	ArrayList phoneNumber;
	
	public MyDB() {
		phoneNumber = new ArrayList();
		phoneNumber.add("1234");
		phoneNumber.add("5678");
		phoneNumber.add("910");
	}
	
	


}
